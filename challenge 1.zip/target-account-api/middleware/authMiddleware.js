const jwt = require('jsonwebtoken');

const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];

  console.log("🔐 Auth Header:", req.headers.authorization);
  console.log("🧪 Extracted Token:", token);

  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  req.user = decoded;
  next();
};

module.exports = authenticate;
