// routes/accountRoutes.js
const express = require('express');
const router = express.Router();
const { getAccounts, updateStatus,addCompany } = require('../controllers/accountController');

router.get('/accounts', getAccounts);
router.post('/accounts/:id/status', updateStatus);
router.post('/accounts', addCompany);

module.exports = router;
