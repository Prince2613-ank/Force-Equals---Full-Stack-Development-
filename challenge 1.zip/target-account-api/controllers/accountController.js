// accountController.js
const companies = require('../data/companies');  // <-- Correct file import

exports.getAccounts = (req, res) => {
  res.json(companies);
};

exports.addCompany = (req, res) => {
  const { name, matchScore, status } = req.body;
  const newCompany = {
    id: companies.length + 1,
    name,
    matchScore,
    status
  };
  companies.push(newCompany);
  res.json({ message: 'Company added', company: newCompany });
};

exports.updateStatus = (req, res) => {
  const id = parseInt(req.params.id);
  const { status } = req.body;
  const company = companies.find(c => c.id === id);
  
  if (company) {
    company.status = status;
    res.json({ message: "Status updated successfully" });
  } else {
    res.status(404).json({ message: "Company not found" });  // Added error handling for not found
  }
};
