const users = [
  { username: "user1", password: "pass123" },
  { username: "user2", password: "pass456" }
];

module.exports = users;
