const companies = [
  { id: 1, name: "Company A", matchScore: 92, status: "Target" },
  { id: 2, name: "Company B", matchScore: 80, status: "Interested" }
];

module.exports = companies;
